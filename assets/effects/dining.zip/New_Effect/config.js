/*@__MAKEUP_API_START__*/
'use strict';

const studio = require('./studio.js');

Object.assign(globalThis, studio.m);
/* Feel free to add your custom code below */














/*@__BACKGROUND_IMPORT_START__*/
Background.texture("environment/background/dining.jpg")
/*@__BACKGROUND_IMPORT_END__*/
/*@__MAKEUP_API_END__*/