/*@__MAKEUP_API_START__*/
'use strict';

const studio = require('./studio.js');

Object.assign(globalThis, studio.m);
/* Feel free to add your custom code below */


















/*@__BACKGROUND_IMPORT_START__*/
Background.texture("environment/background/40985a9f_c8f6_48fb_b5f2_b71d7cf7c4c5.jpg")
/*@__BACKGROUND_IMPORT_END__*/
/*@__MAKEUP_API_END__*/