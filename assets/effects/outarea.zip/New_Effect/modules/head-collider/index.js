'use strict';

require('bnb_js/global');
const modules_scene_index = require('../scene/index.js');

const fragmentShader = "modules/head-collider/head.frag";

const vertexShader = "modules/head-collider/head.vert";

class HeadCollider {
    constructor() {
        Object.defineProperty(this, "_head", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new modules_scene_index.Mesh(new modules_scene_index.FaceGeometry(), new modules_scene_index.ShaderMaterial({
                vertexShader,
                fragmentShader,
                state: {
                    colorWrite: false,
                    zTest: true,
                    zWrite: true,
                    blending: "OFF",
                },
            }))
        });
        modules_scene_index.add(this._head);
    }
}

exports.HeadCollider = HeadCollider;
